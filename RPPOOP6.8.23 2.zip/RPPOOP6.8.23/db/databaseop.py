import pandas as pd
import sqlite3
import streamlit as st
import os
import io
import base64




def get_download_link(df):
    # Create a BytesIO object to store the Excel file
    excel_file = io.BytesIO()

    # Write the DataFrame to the BytesIO object as an Excel file
    with pd.ExcelWriter(excel_file, engine='xlsxwriter') as writer:
        df.to_excel(writer, index=False)

    # Seek to the beginning of the BytesIO object
    excel_file.seek(0)

    # Encode the Excel file as base64
    b64 = base64.b64encode(excel_file.read()).decode()

    # Create the download link for the Excel file
    href = f'<a href="data:application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;base64,{b64}" download="download.xlsx">Download Excel File</a>'

    return href



    
#--------

# Read data from an Excel sheet
def read_excel_data(upload_file, default_file_path):
    if upload_file is not None:
        # Read from the uploaded Excel sheet
        df = pd.read_excel(upload_file)
        st.success("Reading data from the uploaded Excel sheet...")
    else:
        # Read from the default Excel sheet
        df = pd.read_excel(default_file_path)
        st.info("Reading data from the default Excel sheet...")

    return df


def create_database_with_data(df):
    db_path = os.path.join(os.path.dirname(__file__), '..', 'db', 'members.db')
    if not os.path.exists(db_path):
        connection = sqlite3.connect(db_path)
        df.to_sql('members', connection, if_exists='replace', index=False)

        #connection.close()
        print("Database created successfully")
    else:
        print("Database already exists")

def create_database_with_data2(df):
        db_path = os.path.join(os.path.dirname(__file__), '..', 'db', 'members.db')
 
        connection = sqlite3.connect(db_path)
        cursor = connection.cursor()
        
        cursor.execute('DROP TABLE IF EXISTS members')

        #df.to_sql('members', connection, if_exists='replace', index=False)
    
        # Get column names and datatypes from the DataFrame
        columns = df.columns.tolist()
        datatypes = df.dtypes.tolist()
    
    
        # Create the 'members' table
        column_definitions = [f"{col} {dtype}" for col, dtype in zip(columns, datatypes)]
        create_table_query = f"CREATE TABLE members ({', '.join([f'{col} {dtype}' for col, dtype in zip(columns, datatypes)])})"
        cursor.execute(create_table_query)

        # Insert data into the 'members' table
        insert_query = f"INSERT INTO members VALUES ({', '.join(['?'] * len(columns))})"

        # Iterate over each row in the DataFrame and insert into the table
        for index, row in df.iterrows():
           values = tuple(row)  # Convert row values to a tuple
           cursor.execute(insert_query, values)
        
#    connection.execute("""ALTER TABLE members
#                            ADD COLUMN 'Task_to_Complete' 'text';
#                            """)
#    connection.execute("""ALTER TABLE members
#                            ADD COLUMN 'Task_completed'  'text';
#                            """)

       # Commit the changes and close the connection

        connection.commit()
        connection.close()
        st.success("Database is active")

        
def display_portfolios(p):
    st.header('Current Portfolios')
    for key, value in p.items():
        st.write(f"{key}: {value}")



#to set connection with database
def create_connection(db_file):
    connection = None
    try:
        connection = sqlite3.connect(db_file)
        print("Connection to SQLite database successful")
    except sqlite3.Error as e:
        print(f"Error connecting to SQLite database: {e}")
    return connection

def delete_column_from_dataframe(database, table_name, column_name):
    # Connect to the database
    db_path = os.path.join(os.path.dirname(__file__), '..', 'db', 'members.db')
    connection = sqlite3.connect(db_path)

    # Check if the column exists in the table
    cursor = connection.cursor()
    cursor.execute(f"PRAGMA table_info({table_name})")
    columns = cursor.fetchall()
    existing_columns = [column[1] for column in columns]
    if column_name not in existing_columns:
        connection.close()
        return

    # Execute the ALTER TABLE query to delete the column
    alter_query = f"ALTER TABLE {table_name} DROP COLUMN {column_name}"
    connection.execute(alter_query)

    # Commit the changes and close the connection
    connection.commit()
    connection.close()


def add_column_to_dataframe(database, table_name, column_name, column_type):
    # Connect to the database
    db_path = os.path.join(os.path.dirname(__file__), '..', 'db', database)
    connection = sqlite3.connect(db_path)

    # Execute the ALTER TABLE query to add a new column
    alter_query = f"ALTER TABLE {table_name} ADD COLUMN {column_name} {column_type}"
    connection.execute(alter_query)

    # Commit the changes and close the connection
    connection.commit()
    connection.close()



def update_student_data(db_path, student_name, column_name, new_data):
    # Connect to the database
    connection = sqlite3.connect(db_path)
    cursor = connection.cursor()

    # Check if the data for the student already exists
    select_query = f"SELECT * FROM members WHERE StudentName = ?"
    cursor.execute(select_query, (student_name,))
    data = cursor.fetchone()

    if data:
        # Update the existing data
        update_query = f"UPDATE members SET {column_name} = ? WHERE StudentName = ?"
        cursor.execute(update_query, (new_data, student_name))
    else:
        # Insert new data for the student
        insert_query = f"INSERT INTO members (StudentName, {column_name}) VALUES (?, ?)"
        cursor.execute(insert_query, (student_name, new_data))

    # Commit the changes and close the connection
    connection.commit()
    connection.close()
    
def update_table2(table, password):
    db_path = os.path.join(os.path.dirname(__file__), '..', 'db', 'members.db')
    connection = sqlite3.connect(db_path)
    cursor = connection.cursor()
    phead = get_portfolios_from_database('passwordsforheads.db')
    portfolio_name = phead[password]
 
    condition = f"Portfolio == '{portfolio_name}'"
    query = f"SELECT * FROM members WHERE {condition}"
    cursor.execute(query)
     # Fetch the updated data from the database
 
    data = cursor.fetchall()
    column_names = [description[0] for description in cursor.description]

    # Create a new DataFrame with the updated data
    df = pd.DataFrame(data, columns=column_names)

    # Update the displayed DataFrame
    table.dataframe(df)
    csv_link = get_download_link(df)
    st.markdown(csv_link, unsafe_allow_html=True)
    connection.close()



def remove_student_details(db_path, student_name, column_name):
    # Connect to the database
    connection = sqlite3.connect(db_path)
    cursor = connection.cursor()

    # Remove the student details from the specified column
    query = f"UPDATE members SET {column_name} = NULL WHERE StudentName = ?"
    cursor.execute(query, (student_name,))

    # Commit the changes and close the connection
    connection.commit()
    connection.close()



def update_table(cursor, table):
            
    db_path = os.path.join(os.path.dirname(__file__), '..', 'db', 'members.db')
    connection = sqlite3.connect(db_path)
    cursor = connection.cursor()
    # Fetch the updated data from the database
    cursor.execute('SELECT * FROM members')
    data = cursor.fetchall()
    column_names = [description[0] for description in cursor.description]

    # Create a new DataFrame with the updated data
    df = pd.DataFrame(data, columns=column_names)

    # Update the displayed DataFrame
    table.dataframe(df)
    connection.close()
    
    
def sortDisplay(condition):
            
            db_path = os.path.join(os.path.dirname(__file__), '..', 'db', 'members.db')
            connection = sqlite3.connect(db_path)
            cursor = connection.cursor()
                # Execute an SQL query with a condition
            query = f"SELECT * FROM members WHERE {condition}"
            
            cursor.execute(query)

            data = cursor.fetchall()
            # Get the column names from the cursor description
            column_names = [description[0] for description in cursor.description]

            # Create a DataFrame from the fetched data
            df = pd.DataFrame(data, columns=column_names)
            pd.options.display.float_format = '{:.0f}'.format
            df.rename_axis('Custom Index', axis='index', inplace=True)
            table = st.dataframe(df)
            return df
            # Close the database connection
            connection.close()
    
    
    
    
#--------- PASSWORD DATABASES ---------

def find_key_by_value(dictionary, value):
    for key, val in dictionary.items():
        if val == value:
            return key
    return None  # Return None if the value is not found

def create_database_with_data_inpasswords(portfolios):
    db_path = os.path.join(os.path.dirname(__file__), '..', 'db', 'passwordofsec.db')
    if not os.path.exists(db_path):
        connection = sqlite3.connect(db_path)
        cursor = connection.cursor()

        # Create a table for portfolios
        cursor.execute('CREATE TABLE portfolios (key TEXT PRIMARY KEY, value TEXT)')

        # Insert the data from the portfolios dictionary into the table
        for key, value in portfolios.items():
            cursor.execute('INSERT INTO portfolios (key, value) VALUES (?, ?)', (key, value))

        # Commit the changes and close the connection
        connection.commit()
        connection.close()

        print("Database is active")
    else:
        print("Database already exists")
        
def display_portfolios(p):
    st.header('Current Portfolios')
    for key, value in p.items():
        st.write(f"{key}: {value}")
        
        
def rewrite_database_with_data_alter(portfolios, database, index,keyinput):
    db_path = os.path.join(os.path.dirname(__file__), '..', 'db', database)

    connection = sqlite3.connect(db_path)
    cursor = connection.cursor()

    # Check if the 'portfolios' table exists
    cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='portfolios'")
    table_exists = cursor.fetchone()

    # If the table exists, retrieve the existing keys from the table
    existing_keys = set()
    if table_exists:
        cursor.execute('SELECT key FROM portfolios')
        rows = cursor.fetchall()
        existing_keys = set(row[0] for row in rows)

    # Get the new keys that are not present in the database
    

    # Insert the new key-value pairs into the table
    if index == '1' :
     new_keys = set(portfolios.keys()) - existing_keys
     for key in new_keys:
         cursor.execute('INSERT INTO portfolios (key, value) VALUES (?, ?)', (key, portfolios[key]))
    if index == '2' :
     if keyinput in existing_keys:
      keys_remove = existing_keys - set(portfolios.keys())
      for key in keys_remove:
         cursor.execute('DELETE FROM portfolios WHERE key = ?', (key,))
     else:
             st.error('Key is not valid.')
    

    # Commit the changes and close the connection
    connection.commit()
    connection.close()

    st.success("Database is active")
 
    

def update_portfolios(portfolios,database):
    st.header('Update Portfolios')
    old_key = st.selectbox('Select a key to update:', list(portfolios.keys()))
    new_key = st.text_input('Enter a new key:', value=old_key)
 

    if new_key != old_key:
        # Update the key in the portfolios dictionary
        value = portfolios[old_key]
        del portfolios[old_key]
        portfolios[new_key] = value

    #st.write('Portfolios updated:', portfolios)
    rewrite_database_with_data(portfolios,database)
    

    

def update_portfoliosforhead(portfolios,database, passwordofhead,portfoliofhead):
    
    st.header('Update Portfolios')
    old_keyval = portfoliofhead[passwordofhead];
    old_key = find_key_by_value(portfolios, old_keyval)
    if old_key is None:
      st.error("No password for Coords Yet")
    else:
      new_key = st.text_input('Enter a new key:', value=old_key)
      if new_key != old_key:
        # Update the key in the portfolios dictionary
        value = portfolios[old_key]
        del portfolios[old_key]
        portfolios[new_key] = value

    #st.write('Portfolios updated:', portfolios)
    rewrite_database_with_data(portfolios,database)
    
def remove_element(p,database):
    st.header('Remove Element from Portfolios')
    key = st.text_input('Select a key to remove:')
    if key:
      p.pop(key, None)
    else:
      st.error('The key must be provided.')
    #st.write('Portfolios updated:', p)
    rewrite_database_with_data_alter(p, database,'2',key)


def add_element(p,database):
    st.header('Add Element to Portfolios')
    key = st.text_input('Enter a new key:')
    value = st.text_input('Enter a new value:')
    if st.button('Add'):
        if key and value:
            p[key] = value
            st.success('Element added successfully!')
        else:
            st.error('Both key and value must be provided.')
    #st.write('Portfolios updated:', p)
    rewrite_database_with_data_alter(p, database,'1',key)


        

def rewrite_database_with_data(portfolios,database):
    db_path = os.path.join(os.path.dirname(__file__), '..', 'db', database)

    connection = sqlite3.connect(db_path)
    cursor = connection.cursor()
    # Check if the 'portfolios' table exists
    cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='portfolios'")
    table_exists = cursor.fetchone()

    # If the table exists, retrieve the existing keys from the table
    existing_keys = set()
    if table_exists:
        cursor.execute('SELECT key FROM portfolios')
        rows = cursor.fetchall()
        existing_keys = set(row[0] for row in rows)
    # Drop the existing 'members' table if it exists
    new_keys = set(portfolios.keys()) - existing_keys
    keys_remove = existing_keys - set(portfolios.keys())
    cursor.execute('DROP TABLE IF EXISTS portfolios')

    # Create a table for portfolios
    cursor.execute('CREATE TABLE portfolios (key TEXT PRIMARY KEY, value TEXT)')
    


     #Insert the data from the portfolios dictionary into the table
    for key, value in portfolios.items():
        cursor.execute('INSERT INTO portfolios (key, value) VALUES (?, ?)', (key, value))



    # Commit the changes and close the connection
    connection.commit()
    connection.close()

    st.success("Database is active")
    
def get_portfolios_from_database(dbname):
    db_path = os.path.join(os.path.dirname(__file__), '..', 'db', dbname)
    if not os.path.exists(db_path):
        print("Database does not exist")
        return None

    connection = sqlite3.connect(db_path)
    cursor = connection.cursor()

    # Retrieve the data from the "portfolios" table
    cursor.execute('SELECT key, value FROM portfolios')
    rows = cursor.fetchall()

    # Create a dictionary to store the portfolios data
    portfolios = {}
    for row in rows:
        key, value = row
        portfolios[key] = value

    # Close the connection
    connection.close()

    return portfolios
    
    


       


    

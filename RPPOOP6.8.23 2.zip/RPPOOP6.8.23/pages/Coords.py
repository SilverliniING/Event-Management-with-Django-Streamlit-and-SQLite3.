import streamlit as st
from db.databaseop import *
from io import BytesIO



pcoord = get_portfolios_from_database('passwordsforcoords.db')


st.title('COORD INTERFACE')
if "my_input" not in st.session_state:
      st.session_state["my_input"] = ''
      
if not st.session_state["my_input"]:
      st.header("Login Page")
      password =  st.text_input('2 Factor Authentication', st.session_state["my_input"])
      if password in pcoord:
          st.session_state["my_input"] = password
          st.success("Login successful!")
          st.experimental_rerun()
      elif password != "":
            st.error("Invalid password!")
            
else:
            key = st.session_state["my_input"]
         
            portfolio_value = pcoord[key]
            st.subheader(portfolio_value)
         
     
            #condition = f"Portfolio == '{portfolio_value}' and Designation_in_club='Coordinator'"
            if st.sidebar.checkbox('Find your name?'):
                name = ''
                name =  st.sidebar.text_input('Your name')
                condition = f"Portfolio == '{portfolio_value}' and StudentName='{name}'"
                df = sortDisplay(condition)
                if name in df['StudentName'].values:
                  pass
                elif name is '':
                  st.write("Enter name please.")
                else:
                  st.write("Name not found in database.")
                
            else:
                condition = f"Portfolio == '{portfolio_value}' and Designation_in_club IN ('Coordinator', 'coordinator', 'coord', 'Coord', 'COORD', 'COORDINATOR') "
                #condition = f"Portfolio == '{portfolio_value}' and Designation_in_club='Coordinator'"
                sortDisplay(condition)

            


   
    

















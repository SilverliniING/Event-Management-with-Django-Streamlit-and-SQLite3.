
import streamlit as st
import pandas as pd
import os
import sqlite3
from io import BytesIO
from db.databaseop import *
import base64
import io


st.title('HEAD INTERFACE')
phead = get_portfolios_from_database('passwordsforheads.db')
pcoord = get_portfolios_from_database('passwordsforcoords.db')
pbackup = get_portfolios_from_database('passwordsforbackup.db')

if 'my_string' not in st.session_state:
      st.session_state['my_string'] = ''
def login_page():

#    if "authenticated" not in st.session_state:
#        st.session_state["authenticated"] = False

   # if not st.session_state["authenticated"]:
 if not st.session_state['my_string']:
        st.header("Login Page")
        password =  st.text_input('2 Factor Authentication', st.session_state['my_string'])
        
       # password = st.text_input("Password", type="password")
        if password in phead:
            st.session_state['my_string'] = password
            #st.session_state["authenticated"] = True
            st.success("Login successful!")
        
            st.experimental_rerun()

        elif password != "":
            st.error("Invalid password!")

 else:


    db_path = os.path.join(os.path.dirname(__file__), '..', 'db', 'members.db')
    #create_database_with_data(df)

    # Connect to the database
    connection = sqlite3.connect(db_path)
    cursor = connection.cursor()


    password = st.session_state['my_string']
    portfolio_name = phead[password]
   
        
    key = st.session_state['my_string']
    portfolio_value = phead[key]
    st.subheader(portfolio_value)
         

    if st.sidebar.checkbox('Find your name?'):
                name = ''
                name =  st.sidebar.text_input('Your name')
                condition = f"Portfolio == '{portfolio_value}' and StudentName='{name}'"
                df = sortDisplay(condition)
                if name in df['StudentName'].values:
                  pass
                elif name is '':
                  st.write("Enter name please.")
                else:
                  st.write("Name not found in database.")
    else:
        condition = f"Portfolio == '{portfolio_name}'"
        query = f"SELECT * FROM members WHERE {condition}"
        cursor.execute(query)
     
        # Fetch all rows from the result
        data = cursor.fetchall()
        # Get the column names from the cursor description
        column_names = [description[0] for description in cursor.description]

        # Create a DataFrame from the fetched data
        df = pd.DataFrame(data, columns=column_names)
        pd.options.display.float_format = '{:.0f}'.format
        df.rename_axis('Custom Index', axis='index', inplace=True)
        table = st.dataframe(df)
        csv_link = get_download_link(df)
        st.markdown(csv_link, unsafe_allow_html=True)

        st.sidebar.title("Edit the database")
        selected_option = st.sidebar.selectbox("Select an option", [
            "None",
            "Edit Student Data",
            "Remove Student Data",
            "Password Editing"
        ])

        # Add column
        if selected_option == "None":
            pass
        # Edit Coord Password
        elif selected_option == "Password Editing":
             password = st.session_state['my_string']
             update_portfoliosforhead(pcoord,'passwordsforcoords.db',password,phead)


         
             
            

        
    
        # Edit Student Data
        elif selected_option == "Edit Student Data":
         st.title("Edit Student Data")

    # Get user input for update
         student_name = st.text_input("Enter Student Name")
         column_name = st.text_input("Enter Column Name")
         new_data = st.text_input("Enter New Data")
         
         if st.button("Update Student Data"):
          if student_name:
            # Check if the 'StudentName' column exists in the database table
            connection = sqlite3.connect(db_path)
            cursor = connection.cursor()
            cursor.execute(f"PRAGMA table_info(members)")
            columns = [column[1] for column in cursor.fetchall()]
            connection.close()
            if 'StudentName' in columns:
                # Check if the student name exists in the 'StudentName' column
                connection = sqlite3.connect(db_path)
                cursor = connection.cursor()
                cursor.execute(f"SELECT StudentName FROM members WHERE StudentName = '{student_name}'")
                data = cursor.fetchone()
                connection.close()
                if data is not None:
                    if column_name in columns:
                        connection = sqlite3.connect(db_path)
                        cursor = connection.cursor()
                        # Check if the column has data for the specified student
                        cursor.execute(f"SELECT {column_name} FROM members WHERE StudentName = '{student_name}'")
                        #data = cursor.fetchone()
                        #if data is not None and data[0] is not None:
                        connection.close()
                        if new_data is not None:
                            update_student_data(db_path, student_name, column_name, new_data)
                            st.success("Student data updated successfully!")
                            password = st.session_state['my_string']
                            update_table2(table, password)
                        else:
                            st.warning("No data to add, you may be looking for the remove function.")
                    else:
                        st.warning("Please enter the correct column name.")
                else:
                    st.warning("Student name not found.")
            else:
                st.warning("The 'StudentName' column does not exist in the database table.")
          else:
        
            st.warning("Please enter the student name.")
       

        elif selected_option == "Remove Student Data":
         st.title("Remove Student Data")

    # Get user input for update
         student_name = st.text_input("Enter Student Name")
         column_name = st.text_input("Enter Column Name")
         if st.button("Remove Student Data"):
          if student_name:
            connection = sqlite3.connect(db_path)
            cursor = connection.cursor()
            # Check if the 'StudentName' column exists in the database table
            cursor.execute(f"PRAGMA table_info(members)")
            columns = [column[1] for column in cursor.fetchall()]
            connection.close()
            if 'StudentName' in columns:
                # Check if the student name exists in the 'StudentName' column
                connection = sqlite3.connect(db_path)
                cursor = connection.cursor()
                cursor.execute(f"SELECT StudentName FROM members WHERE StudentName = '{student_name}'")
                data = cursor.fetchone()
                connection.close()
                if data is not None:
                    if column_name in columns:
                        # Check if the column has data for the specified student
                        connection = sqlite3.connect(db_path)
                        cursor = connection.cursor()
                        cursor.execute(f"SELECT {column_name} FROM members WHERE StudentName = '{student_name}'")
                        data = cursor.fetchone()
                        connection.close()
                        if data is not None and data[0] is not None:
                            remove_student_details(db_path, student_name, column_name)
                            st.success("Student data removed successfully!")
                            update_table2(table,password)
                        else:
                            st.warning("No data to remove.")
                    else:
                        st.warning("Please enter the correct column name.")
                else:
                    st.warning("Student name not found.")
            else:
                st.warning("The 'StudentName' column does not exist in the database table.")

                
          else:
            st.warning("Please enter the student name.")

 


        connection.close()


if __name__ == "__main__":
    login_page()

import streamlit as st
import pandas as pd
import os
import sqlite3
from io import BytesIO
import base64
from db.databaseop import *
import io



st.title('SECRETARY INTERFACE')
phead = get_portfolios_from_database('passwordsforheads.db')
pcoord = get_portfolios_from_database('passwordsforcoords.db')
pbackup = get_portfolios_from_database('passwordsforbackup.db')
psec = get_portfolios_from_database('passwordofsec.db')



def update_database(df):
    # Specify the database path
    db_path = os.path.join(os.path.dirname(__file__), '..', 'db', 'members.db')

    # Create or connect to the database
    connection = sqlite3.connect(db_path)
    cursor = connection.cursor()

    # Drop the existing 'members' table if it exists
    cursor.execute('DROP TABLE IF EXISTS members')
    
    #df.to_sql('members', connection, if_exists='replace', index=False)
    
    # Get column names and datatypes from the DataFrame
    columns = df.columns.tolist()
    datatypes = df.dtypes.tolist()
    
    # Create the 'members' table
    column_definitions = [f"{col} {dtype}" for col, dtype in zip(columns, datatypes)]
    create_table_query = f"CREATE TABLE members ({', '.join([f'{col} {dtype}' for col, dtype in zip(columns, datatypes)])})"
    cursor.execute(create_table_query)

    # Insert data into the 'members' table
    insert_query = f"INSERT INTO members VALUES ({', '.join(['?'] * len(columns))})"

    # Iterate over each row in the DataFrame and insert into the table
    for index, row in df.iterrows():
        values = tuple(row)  # Convert row values to a tuple
        cursor.execute(insert_query, values)
        
#    connection.execute("""ALTER TABLE members
#                            ADD COLUMN 'Task_to_Complete' 'text';
#                            """)
#    connection.execute("""ALTER TABLE members
#                            ADD COLUMN 'Task_completed'  'text';
#                            """)

    # Commit the changes and close the connection
    connection.commit()
    connection.close()






def login_page():
    if "authenticated" not in st.session_state:
        st.session_state["authenticated"] = False

    if not st.session_state["authenticated"]:
        st.header("Login Page")
        password = st.text_input("Password", type="password")
        if password in psec:  # Replace "your_password" with your actual password
            st.session_state["authenticated"] = True
            st.success("Login successful!")

            st.experimental_rerun()

        elif password != "":
            st.error("Invalid password!")

    else:
        st.subheader(" ")
        st.subheader(" ")
        st.text("Click below to upload a new file or continue in the sidebar with the default file")
        uploaded_file = st.file_uploader("Upload Excel file", type=["xlsx"])
    
        if uploaded_file is not None:
            content = uploaded_file.read()
            df = pd.read_excel(BytesIO(content))
            #create_database_with_data2(df)
            #update_database(df)
        
            
        else:
           #default_file_path = os.path.join(os.path.dirname(__file__), '..', 'db', 'fest.xlsx')
           default_file_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'db', 'fest.xlsx')
           df = pd.read_excel(default_file_path)
           
           
           
        create_database_with_data2(df)
      

        db_path = os.path.join(os.path.dirname(__file__), '..', 'db', 'members.db')
        # Connect to the database
        connection = sqlite3.connect(db_path)
        cursor = connection.cursor()
        

        # Execute a query to fetch data from the database
        cursor.execute('SELECT * FROM members')

        # Fetch all rows from the result
        data = cursor.fetchall()
        # Get the column names from the cursor description
        column_names = [description[0] for description in cursor.description]
       
        # Create a DataFrame from the fetched data
        df = pd.DataFrame(data, columns=column_names)

        
        pd.options.display.float_format = '{:.0f}'.format
        df.rename_axis('Custom Index', axis='index', inplace=True)
        table = st.dataframe(df)
        
        
        
        csv_link = get_download_link(df)
        st.markdown(csv_link, unsafe_allow_html=True)
        
        


        st.sidebar.title("Edit the database")
        selected_option = st.sidebar.selectbox("Select an option", [
            "None",
            "Add Column",
            "Delete Column",
            "Edit Student Data",
            "Remove Student Data",
            "Password Editing"
        ])


        # Add column
        if selected_option == "None":
            pass
        # Edit Passwords
        elif selected_option == "Password Editing":
          selected_option2 = st.selectbox("Select an option", [
                         "None",
            "Add Portfolio Password for Head",
            "Edit Portfolio Password for Head",
            "Remove Portfolio Password for Head",
            "Edit Personal Password",
           
            
             
          ])
          if selected_option2 == "None":
            pass
          elif selected_option2 == "Edit Personal Password":
            update_portfolios(psec,'passwordofsec.db')
          # Edit Student Password
       
          elif selected_option2 == "Add Portfolio Password for Head":
             add_element(phead,'passwordsforheads.db')
          elif selected_option2 == "Edit Portfolio Password for Head":
             update_portfolios(phead,'passwordsforheads.db')
          elif selected_option2 == "Remove Portfolio Password for Head":
             remove_element(phead,'passwordsforheads.db')

             
       
          elif selected_option2 == "Add Portfolio Password for  Coord":
             add_element(phead,'passwordsforheads.db')
          elif selected_option2 == "Edit Portfolio Password for Coord":
             update_portfolios(phead,'passwordsforheads.db')
          elif selected_option2 == "Remove Portfolio Password for Coord":
             remove_element(phead,'passwordsforheads.db')
             remove_element(pcoord,'passwordsforheads.db')
             
  
             
             
        
         
             
            

        elif selected_option == "Add Column":
            st.title("Add Column")
            column_name = st.text_input('Enter column name')
            column_type = st.selectbox('Select column type', ['INTEGER', 'TEXT', 'REAL'])
            if st.button('Add Column'):
                if column_name and column_type:
                    add_column_to_dataframe('members.db', 'members', column_name, column_type)
                    st.success(f"Column '{column_name}' added successfully!")
                    update_table(cursor, table)
                else:
                    st.warning('Please enter column name and select column type.')

        # Delete column
        elif selected_option == "Delete Column":
            st.title("Delete Column")
            column_name_to_delete = st.text_input('Enter column name to delete')
            if st.button('Delete Column'):
                if column_name_to_delete:
                    delete_column_from_dataframe('members.db', 'members', column_name_to_delete)
                    st.success(f"Column '{column_name_to_delete}' deleted successfully!")
                    update_table(cursor, table)
                else:
                    st.warning('Please enter column name to delete.')
                    
        # Edit Student Data
        elif selected_option == "Edit Student Data":
         st.title("Edit Student Data")

    # Get user input for update
         student_name = st.text_input("Enter Student Name")
         column_name = st.text_input("Enter Column Name")
         new_data = st.text_input("Enter New Data")
         
         if st.button("Update Student Data"):
          if student_name:
            # Check if the 'StudentName' column exists in the database table
            connection = sqlite3.connect(db_path)
            cursor = connection.cursor()
            cursor.execute(f"PRAGMA table_info(members)")
            columns = [column[1] for column in cursor.fetchall()]
            connection.close()
            if 'StudentName' in columns:
                # Check if the student name exists in the 'StudentName' column
                connection = sqlite3.connect(db_path)
                cursor = connection.cursor()
                cursor.execute(f"SELECT StudentName FROM members WHERE StudentName = '{student_name}'")
                data = cursor.fetchone()
                connection.close()
                if data is not None:
                    if column_name in columns:
                        connection = sqlite3.connect(db_path)
                        cursor = connection.cursor()
                        # Check if the column has data for the specified student
                        cursor.execute(f"SELECT {column_name} FROM members WHERE StudentName = '{student_name}'")
                        #data = cursor.fetchone()
                        #if data is not None and data[0] is not None:
                        connection.close()
                        if new_data is not None:
                            update_student_data(db_path, student_name, column_name, new_data)
                            st.success("Student data updated successfully!")
                            update_table(cursor, table)
                        else:
                            st.warning("No data to add, you may be looking for the remove function.")
                    else:
                        st.warning("Please enter the correct column name.")
                else:
                    st.warning("Student name not found.")
            else:
                st.warning("The 'StudentName' column does not exist in the database table.")
          else:
        
            st.warning("Please enter the student name.")
       

        elif selected_option == "Remove Student Data":
         st.title("Remove Student Data")

    # Get user input for update
         student_name = st.text_input("Enter Student Name")
         column_name = st.text_input("Enter Column Name")
         if st.button("Remove Student Data"):
          if student_name:
            connection = sqlite3.connect(db_path)
            cursor = connection.cursor()
            # Check if the 'StudentName' column exists in the database table
            cursor.execute(f"PRAGMA table_info(members)")
            columns = [column[1] for column in cursor.fetchall()]
            connection.close()
            if 'StudentName' in columns:
                # Check if the student name exists in the 'StudentName' column
                connection = sqlite3.connect(db_path)
                cursor = connection.cursor()
                cursor.execute(f"SELECT StudentName FROM members WHERE StudentName = '{student_name}'")
                data = cursor.fetchone()
                connection.close()
                if data is not None:
                    if column_name in columns:
                        # Check if the column has data for the specified student
                        connection = sqlite3.connect(db_path)
                        cursor = connection.cursor()
                        cursor.execute(f"SELECT {column_name} FROM members WHERE StudentName = '{student_name}'")
                        data = cursor.fetchone()
                        connection.close()
                        if data is not None and data[0] is not None:
                          remove_student_details(db_path, student_name, column_name)
                          update_table(cursor, table)
                          st.success("Student data removed successfully!")
                           
                        else:
                            st.warning("No data to remove.")
                    else:
                        st.warning("Please enter the correct column name.")
                else:
                    st.warning("Student name not found.")
            else:
                st.warning("The 'StudentName' column does not exist in the database table.")

                
          else:
            st.warning("Please enter the student name.")
#=======
#        # Edit Student Data
#        elif selected_option == "Edit Student Data":
#            st.title("Edit Student Data")
#
#            # Get user input for update
#            student_name = st.text_input("Enter Student Name")
#            column_name = st.text_input("Enter Column Name")
#            new_data = st.text_input("Enter New Data")
#
#            if st.button("Update Student Data"):
#                if student_name and column_name and new_data:
#                    update_student_data(db_path, student_name, column_name, new_data)
#                    st.success("Student data updated successfully!")
#                    update_table(cursor, table)
#                else:
#                    st.warning("Please enter all the required information.")
                    
                    



#        # Remove Student Data
#        elif selected_option == "Remove Student Data":
#            st.title("Remove Student Data")
#
#            # Get user input for update
#            student_name = st.text_input("Enter Student Name")
#            column_name = st.text_input("Enter Column Name")
#
#            if st.button("Remove Student Data"):
#                if student_name:
#                    remove_student_details(db_path, student_name, column_name)
#                    st.success("Student data removed successfully!")
#                    update_table(cursor, table)
#                else:
#                    st.warning("Please enter the student name.")
#
#
#        # Close the database connection
#        connection.close()
#
#

#=======

if __name__ == "__main__":
    login_page()
